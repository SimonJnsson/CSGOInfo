document.addEventListener("DOMContentLoaded", function()
{
    var DEFAULT_TIMEBEFOREMATCH = 15;
    $('.settingsInput').focus(function()
    {
        $(this).parent().addClass('active');
        $(this).attr('placeholder', '');
    });

    $('.settingsInput').blur(function()
    {
        if ($(this).val() == "")
            $(this).parent().removeClass('active');

        $(this).attr('placeholder', $(this).parent().find('.settingsText').text());
    });

    chrome.storage.sync.get(function(item)
    {
        if (item.timeBeforeMatch != undefined && item.timeBeforeMatch != "")
        {
            $('.timeBeforeMatch').val(item.timeBeforeMatch);
            $('.timeBeforeMatch').parent().addClass('active');
        }
        else if (item.timeBeforeMatch == "")
        {
            $('.timeBeforeMatch').val(DEFAULT_TIMEBEFOREMATCH);
            $('.timeBeforeMatch').parent().addClass('active');
        }
    });

    $('.timeBeforeMatch').change(function()
    {
        var that = $(this);
        chrome.storage.sync.set({
            "timeBeforeMatch": that.val()
        });
    });

    var originalColor = $(".button").css("background-color");
    var originalBorder = $(".button").css("border");

    $(".button").on("click", function() // Change styling when a tab button is clicked
    {
        $(".button").css("background-color", originalColor);
        $(".button").css("border", originalBorder);
        $(this).css("background-color", "#2c3e50");
        $(this).css("border-bottom", "2px solid #2c3e50");
        $(".tab").hide();
        $("#tab" + $(this).attr("alt")).show();
    });

    $("#button1").click(); // Start the extension in the 'tournaments' tab

    var arrow = "img/arrow.png";

    var NAME_MAXLENGTH = 36;

    var tournaments = [];
    var tournamentUrl = "https://api.toornament.com/v1/tournaments";

    currDate = new Date();
    var tournamentEndAfter = (currDate.getFullYear() + '-'
        + ('0' + (currDate.getMonth() + 1)).slice(-2) + '-'
        + ('0' + (currDate.getDate() + 1)).slice(-2));

    // Get Tournaments
    // API Reference https://developer.toornament.com/doc/tournaments/counterstrike_go
    $.ajax({
        type: "GET",
        url: tournamentUrl,
        headers: { "X-Api-Key": "Q6Hu41MTYzjED8a0hNr7x6sSDEc-eUVQvo6qmv4ckp8" },
        data: {
            "discipline": "counterstrike_go",
            "featured": "1",
            "sort": "date_asc",
            "after_end": tournamentEndAfter

        },
        success: function(response)
        {
            tournaments = response;

            $.each(tournaments, function(index, obj)
            {
                var tournamentName = obj.name;
                if (tournamentName.length > NAME_MAXLENGTH) // Limit the length of tournament name
                    tournamentName = tournamentName.substring(0, NAME_MAXLENGTH);

                var rawStartdate = new Date(obj.date_start); // Cast the start date to a new 'Date'
                var startDate = rawStartdate.getDate() + "/" + (rawStartdate.getMonth() + 1) + "/" + rawStartdate.getFullYear(); // Format the newly created 'Date'
                var rawEndDate = new Date(obj.date_end);
                var endDate = rawEndDate.getDate() + "/" + (rawEndDate.getMonth() + 1) + "/" + rawEndDate.getFullYear();
                var tournamentDate = startDate + " - " + endDate; // Combine start and end dates
                console.log(obj);

                var tournamentId = obj.id;

                var teamCount = obj.size;

                var country = obj.country;
                var location = obj.location;

                // String for creating a 'tournament' element
                var tournament = '<div class="tournament" id=' + tournamentId + '>' +
                    '<div class="tournamentInfo">' +
                    '<img class="tournamentLogo" src="img/' + GetTournamentImage(tournamentName) + '.png"/>' +
                    '<img class="arrow" src="' + arrow + '"/>' +
                    '<p class="tournamentName">' + tournamentName + '</p>' +
                    '<p class="tournamentDate">' + tournamentDate + '</p>' +
                    '<p>Teams: ' + teamCount + '</p>' +
                    '</div>' +
                    '<div class="dropdown hidden">' +
                    '<br>' +
                    '<img style="height:13px;" src="img/flags" />' +
                    '</div>' +
                    '</div>';

                $('.tournamentArea').append(tournament);

                var participantUrl = "https://api.toornament.com/v1/tournaments/" + tournamentId + "/participants";
                var participants = [];

                // Get tournament participant info
                // API Reference https://developer.toornament.com/doc/participants/counterstrike_go#get:tournaments:tournament_id:participants
                $.ajax({
                    type: "GET",
                    url: participantUrl,
                    headers: { "X-Api-Key": "Q6Hu41MTYzjED8a0hNr7x6sSDEc-eUVQvo6qmv4ckp8" },
                    data: {
                        "sort": "alphabetic"
                    },
                    success: function(response)
                    {
                        participants = response;

                        $.each(participants, function(index, obj)
                        {
                            var participantName = obj.name;

                            var participant = '<p class="participantName">' + participantName + '</p>';

                            $('#' + tournamentId).find('.dropdown').prepend(participant);
                        });
                    },
                    error: function(error)
                    {
                        //console.log("Error " + error.status + " - " + this.url);
                    }
                });

                var indiTournamentUrl = "https://api.toornament.com/v1/tournaments/" + tournamentId;

                // Get individual tournament info
                // API Reference https://developer.toornament.com/doc/tournaments/counterstrike_go#get:tournaments:id
                $.ajax({
                    type: "GET",
                    url: indiTournamentUrl,
                    headers: { "X-Api-Key": "Q6Hu41MTYzjED8a0hNr7x6sSDEc-eUVQvo6qmv4ckp8" },
                    success: function(response)
                    {
                        var tournementStreams = response.streams;
                        var tournamentStatus = response.status;
                        var tournementWebsite = response.website;
                        //console.log("Status: " + tournamentStatus);

                        if (tournementWebsite != null && tournementWebsite !== 'undefined') // If the obj contains a website
                        {
                            $('#' + tournamentId).find('.tournamentLogo').attr('href', tournementWebsite); // Set the 'href' attribute on the tournament logo
                            $('#' + tournamentId).find('.tournamentLogo').on('click', function() // Create href
                            {
                                chrome.tabs.create({ url: $(this).attr('href') });
                                return false;
                            });
                        }

                        if (tournementStreams.length > 0) // If streams exist, create links to all available english streams
                        {
                            $.each(tournementStreams, function(index, obj)
                            {
                                if (obj.language === "en")
                                {
                                    var currGuid = guid(); // Create a guid for the new elements ID
                                    var streamLink = obj.url;
                                    var linkElement = '<a class="streamLink" id="' + currGuid + '" href="' + streamLink + '"><img src="img/twitchIcon.png"/></a>';

                                    $('#' + tournamentId).find('.dropdown').append(linkElement); // Append the link to the stream

                                    $('#' + currGuid).on('click', function() // Create link on new element
                                    {
                                        chrome.tabs.create({ url: $(this).attr('href') });
                                        return false;
                                    });
                                }
                            });
                        }
                        else
                            $('#' + tournamentId).find('.streamText').hide(); // If there is nothing to show, hide the element
                    },
                    error: function(error)
                    {
                        console.log("Error " + error.status + " - " + this.url);
                    }
                });
            });
        },
        error: function(error)
        {
            console.log("Error " + error.status + " - " + this.url);
        },
        complete: function()
        {
            $(".arrow").on('click', function() // When a tournament element is clicked
            {
                var target = $(this).closest('.tournamentInfo').parent();

                target.find('.dropdown').toggleClass("visible", 'hidden'); // Toggle classes on the dropdown to determine if is should be visible or not
                target.children().children('.arrow').toggleClass('rotated'); // Toggle classes to rotate arrow on click
                // If the dropdown will be below the screen whgen folded down
                if (target.offset().top + target.height() + $('#topBar').outerHeight() - $('body').scrollTop() > $('body').height() && target.find('.dropdown').hasClass('visible'))
                {
                    $('body').animate({
                            scrollTop: target.offset().top - $('#topBar').outerHeight() - target.height() / 2 // Smoothly scroll the element to the top of the screen
                        },
                        1000);
                }
            });

            $(".dropdown").on('click', function(e)
            {
                e.preventDefault();
            });
        }
    });

    var matchUrl = "https://api.toornament.com/v1/disciplines/counterstrike_go/matches";
    var matches = [];

    // Get tournament participant info
    var daysInMonth  = new Date(currDate.getFullYear(), currDate.getMonth() + 1, 0).getDate();
    var getNextMonth = currDate.getDate() + 1 > daysInMonth;
    var getNextYear = getNextMonth && currDate.getMonth() >= 11;
    var currentDate = ((getNextYear ? currDate.getFullYear() + 1 : currDate.getFullYear()) + '-'
        + ('0' + (getNextMonth ? (currDate.getMonth() + 2 > 12 ? 1 : currDate.getMonth() + 2) : currDate.getMonth() + 1)).slice(-2) + '-'
        + ('0' + (getNextMonth ? 1 : currDate.getDate() + 1)).slice(-2));

    $.ajax({
        type: "GET",
        url: matchUrl,
        headers: { "X-Api-Key": "Q6Hu41MTYzjED8a0hNr7x6sSDEc-eUVQvo6qmv4ckp8" },
        data: {
            "featured": "1",
            "sort": "date_asc",
            "after_date": currentDate
        },
        success: function(response)
        {
            matches = response;

            $.each(matches, function(index, obj)
            {
                var tournamentName = obj.tournament.name;
                var teamOne = "";
                var teamTwo = "";
                var rawStartdate = new Date(obj.date); // Cast the start date to a new 'Date'
                var formatMinutes = rawStartdate.getMinutes() < 10 ? "0" + rawStartdate.getMinutes() : rawStartdate.getMinutes();
                var startDate = rawStartdate.getDate() + "/" + ('0' + (rawStartdate.getMonth() + 1)).slice(-2) + "/" + rawStartdate.getFullYear() + " - " + rawStartdate.getHours() + ":" + formatMinutes; // Format the newly created 'Date'
                obj.opponents[0].participant == null ? teamOne = "TBD" : teamOne = obj.opponents[0].participant.name;
                obj.opponents[1].participant == null ? teamTwo = "TBD" : teamTwo = obj.opponents[1].participant.name;
                var tournamentId = obj.tournament.id;
                var matchId = obj.id;
                
                var match = '<div id="' + matchId + '" class="match" data-matchId="' + matchId + '" data-tournamentId="' + tournamentId + '">' +
                               '<div class="matchInfo">' +
                               '<img class="tournamentLogo" src="img/' + GetTournamentImage(tournamentName) + '.png"/>' +
                               '<div class="opponents">' +
                               '<p class="opponentOne">' + teamOne + '</p>' +
                               '<p class="versus"> VS </p>' +
                               '<p class="opponentTwo">' + teamTwo + '</p>' +
                               '<p class="matchStart">' + startDate + '</p>' +
                               '</div>' +
                               '<img class="alarmBtn" src="img/alarmIdle.png"/>' +
                               '</div>' +
                               '</div>';
                           $('.matchArea').append(match);
            });
        },
        error: function(error)
        {
            console.log("Error " + error.status + " - " + this.url);
        },
        complete: function()
        {
            $(".alarmBtn").on('click', function(e)
            {
                $(this).toggleClass('selected');
                saveData($(this));
            });
            loadData();
        }
    });
});

matches = [];
function saveData(dataToAdd)
{
    var matchToAdd = $(dataToAdd).closest('.match');

    match = {
        "matchId"       : $(matchToAdd).attr('data-matchId'),
        "tournamentId"  : $(matchToAdd).attr('data-tournamentId'),
        "matchStart"    : $(matchToAdd).find('.matchStart').text(),
        "matchTeamOne"  : $(matchToAdd).find('.opponentOne').text(),
        "matchTeamTwo"  : $(matchToAdd).find('.opponentTwo').text(),
        "tournamentLogo": $(matchToAdd).find('.tournamentLogo').attr('src'),
        "streamLink"    : $('#'+$(matchToAdd).attr('data-tournamentId')).find('.streamLink').attr('href')
    };

    chrome.storage.sync.get(function(item)
    {
        if (item.match !== undefined)
            matches = item.match;

        var matchAlreadyAdded = false;

        $.each(matches, function(index, obj)
        {
            if (obj.matchId === match.matchId)
            {
                console.log("Match already in storage");
                matches.splice(index, 1);
                matchAlreadyAdded = true;
                return false;
            }
        });

        console.log(matches);
        if (!matchAlreadyAdded)
            matches.push(match);

        chrome.storage.sync.set({
            "match": matches
        });

    });

}

function loadData()
{
    chrome.storage.sync.get("match", function(item)
    {
        $.each(item.match, function(index, obj)
        {
            $('#' + obj.matchId).find(".alarmBtn").addClass('selected');
        });
    });
}

$(document).ready(function()
{
    var arrow = "img/arrow.png";

    $('#toorLogo').on('click', function() // Create link on 'powered by toornament' logo
    {
        chrome.tabs.create({ url: $(this).parent().attr('href') });
        return false;
    });
});

function guid()
{
    function s4()
    {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }

    return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
        s4() + '-' + s4() + s4() + s4();
}

// Get the proper image determined by the name of the tournament
function GetTournamentImage(name) // Get the proper image determined by the name of the tournament
{
    var returnValue = "icon";
    if (name.toLowerCase().indexOf('esl') > -1)
        returnValue = "esl";
    else if (name.toLowerCase().indexOf('starladder') > -1)
        returnValue = "starladder";
    else if (name.toLowerCase().indexOf('ecs') > -1)
        returnValue = "ecs";
    else if (name.toLowerCase().indexOf('red dot') > -1)
        returnValue = "reddot";
    else if (name.toLowerCase().indexOf('esports championship series') > -1)
        returnValue = "ecs";
    else if (name.toLowerCase().indexOf('cevo') > -1)
        returnValue = "cevo";
    else if (name.toLowerCase().indexOf('faceit') > -1 || name.toLowerCase().indexOf('face it') > -1)
        returnValue = "faceit";

    return returnValue;
}